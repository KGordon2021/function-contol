 //Specify the Port to listen on
 const port = process.env.PORT || 8080;

var express = require('express');
var path = require('path');

var createError = require('http-errors');

var flash = require('express-flash');
var session = require('express-session');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var mysql = require('mysql');

//Setup External Files
var conn  = require('./lib/dbConnections');


//will be changing links to js routes folder here
var homeRouter = require('./routes/index');
var RecordRouter = require('./routes/addstudent');

var app = express();
 
// Setup the Views Templating Engine
app.set('views', path.join(__dirname, 'views'));
 app.set('view engine', 'ejs');
 

 app.use(bodyParser.json());
 app.use(bodyParser.urlencoded({ extended: true }));
 //app.use('/public', express.static('public'));// code to use scripts, this is route specific which means it can be used only on specified routes
 app.use('/public', express.static(path.join(__dirname, 'public'))); // in both instance it doesn't work without the '/public' at the beginning. this method doesn't work need to ask Sir about this

 
 //Session Settings
 app.use(cookieParser());
 app.use(session({ 
     secret: 'T3$C@r|8proDj8t',
     resave: false,
     saveUninitialized: true,
     cookie: { maxAge: 120000 }
 }))
 

 app.use(flash());

 //will change these later as well 

 app.use('/', homeRouter); 
 app.use(RecordRouter); // these don't work the same way that sir own works I will have to query this or run some searches on google, stack or git


 app.listen(port, () => console.log(`Listening on port ${port}..`));

 module.exports = app;
 
// function grade() {
//     var grade = document.getElementById('grades').value;
    
//     // document.getElementById("answer").innerHTML = "The result is = " + returnedvalue;


//     if(grade >= 60) {
//         document.getElementById("answered").innerHTML = "You passed ";
//         console.log("You passed")
//     } else {
//         document.getElementById("answered").innerHTML = "You failed. Please Resit ";
//         console.log("Resit Required")
//     }
// }

// function grade2() {

    // var grade = parseInt(document.getElementById('grade').value);

    // switch(true){
    //     case grade >= 80:
    //         document.getElementById("answer").innerHTML = "You Passed: Grade is A ";
    //         break;
    //     case grade >= 70:
    //         document.getElementById("answer").innerHTML = "You Passed: Grade is B ";
    //         break;
    //     case grade >= 60:
    //         document.getElementById("answer").innerHTML = "You Passed: Grade is C ";
    //         break;
    //     case grade >= 50:
    //         document.getElementById("answer").innerHTML = "You Passed: Grade is D ";
    //         break; 
    //     default:
    //         document.getElementById("answer").innerHTML = "You Failed. Please Resit";
    //         break;

//     }
// }