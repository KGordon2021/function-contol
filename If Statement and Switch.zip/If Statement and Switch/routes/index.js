var express = require('express');
var router = express.Router();
var conn = require('../lib/dbConnections')

router.get('/', function(req, res) {
        conn.query('SELECT * FROM students ORDER BY id', function(err, rows){
            if(err) {
            console.log('not being rendered');
            throw err 
            } else {
                res.render('../views/index', {
                    allrequests: rows
                    // mySession: req.session
                });
            }
        })
});



router.get('/student_records/view/:student_id', (req, res) => {
    conn.query('SELECT * FROM function_control_structures.student_grades, function_control_structures.students WHERE function_control_structures.student_grades.student_id AND function_control_structures.students.student_id =' + req.params.student_id, function(err, rows){
        if (err) {
            console.log(err)
        } else {
            console.log(rows);
            res.render('../views/reportCard', {records: rows});
        }
    })
})


router.post('/student_records/update/:student_id', function(req, res, next) {
      
    let sqlQuery = "UPDATE customer_orders SET customer_order ='" + req.body.cust_order +  
                                        "', customer_email ='" +  req.body.cust_email +
                                        "', order_date ='" +  req.body.order_date + 
                                        "' WHERE id = " + req.body.id;

    conn.query(sqlQuery, function(err,rows)     {

        if(err) {
            console.log(err)
        } else {
            res.redirect('/admin');   
            next();
        }   
               //req.flash('error', err); 
                              
            });
           
       });

// //   /* GET ORDERS DELETE METHOD. */
//   router.get('/allrequests/delete/:id', function(req, res, next) {
      
//     conn.query('DELETE FROM books_requested WHERE id='+ req.params.id, function(err,row)     {
    
//            if(err){
//             //    req.flash('error', err); 
//             console.log(err)
              
//            }else{
//             // req.flash('success', 'Deleted successfully!!'); 
//             res.redirect('/allrequests');   
//             next();      
//            }
                               
//             });
           
//        });

       

module.exports = router;