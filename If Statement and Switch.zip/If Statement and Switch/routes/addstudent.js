
var express = require('express');
var router = express.Router();
var conn = require('../lib/dbConnections')

router.get('/add_student', (req, res)=> {
    res.render('../views/addstudent')
})

router.post('/add_st' , (req, res) => {
    var date_approved = new Date().toLocaleDateString('fr-CA')
    let data = {    student_id: req.body.st_id, 
                    f_nm: req.body.f_name, 
                    l_nm: req.body.l_name,
                };

        let sqlQuery = "INSERT INTO students SET ?";
        let vQuery = conn.query(sqlQuery, data,(err, results) => {
        if(err) {
        console.log(err); 
        } else {
        //    res.send(JSONResponse(results));
        res.redirect('/');
        }
        });

    }); 

    module.exports = router;